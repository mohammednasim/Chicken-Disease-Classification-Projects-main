# test_imports.py
try:
    from tensorflow.keras.models import load_model
    from tensorflow.keras.preprocessing import image
    print("Imports successful!")
except ImportError as e:
    print("Import failed:", e)
